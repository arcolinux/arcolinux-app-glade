#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# import gi for gtk and gdk
import gi
# import python logging
import logging
# import datetime for our log file name
import datetime
# Set the correct Gtk version e.g GTK 3, otherwise defaults to version 4
gi.require_version('Gtk','3.0')
# import gtk ver 3 and gdk
from gi.repository import Gtk, Gdk


#########################
# CONSTS
#########################
ALACRITTY_HOLD = "alacritty --hold -e" # Does not change
ALACRITTY_NO_HOLD = "alacritty -e" # Does not change

#########################
# Variables
#########################
command = "some command to perfom" # Changes during execution of the code

# The Main class
class Main:
    def __init__(self):

        logging.info('Building Gui from Glade')
        # Use Gtk builder to build the glade file
        gGui = "gGui.glade"
        self.builder = Gtk.Builder()
        self.builder.add_from_file(gGui)

        logging.info('Connecting signals')
        # Connect all the signals you have set in glade
        self.builder.connect_signals(self)
        
        # Assign the ID used in glade for the main window to hWindow
        hWindow = self.builder.get_object("hWindow")
        
        # Ensure delete event is assigned to quit
        hWindow.connect("delete-event", Gtk.main_quit)

        logging.info('Displaying the main window')
        # Show the window
        hWindow.show()
        
###############################################################
# On click events - we could also move this to another        #
# module(mClick_Events.py file) for example, for cleaner code #
###############################################################  
              
    # When you click the Create Button
    def on_btnCreate_clicked(self, widget):
       #  print("Create Button has been clicked") <--- no need now we have logging
        logging.info('btnCreate Clicked')

    # Checkbox ticked or not, e.g alacritty -hold ??
    def on_chkHold_toggled(self, widget):
       # if widget.get_active():
       #     command = ALACRITTY_HOLD + command
       # else:
       #     command = ALACRITTY_NO_HOLD + command
       
       # Log the current state of of ChkHold,   
        logging.info('CheckToggle %s', widget.get_active()) # example logging with state of component, e.g True, False

    # When changing the drop down box 
    def on_cbIso_changed(self, widget):
        text = widget.get_active_text()
        if text is not None:
            print("Selected: %s" % text)
            logging.info('Combobox changed value %s ', text) # example logging with values
        

# the entry point of the program, here we can set stuff up before calling
# the Main class
if __name__ == "__main__":
    
    # Get time and date for naming the log file
    now = datetime.datetime.now()
    
    # Setup a handler so we can log to file and to the console at the same time
    handlers = [logging.FileHandler('Arcolinux-App-' + now.strftime("%Y-%m-%d-%H:%M:%S") + '.log'),
                logging.StreamHandler()]
    
    # Setup the logger and formatting, also include our file handler
    logging.basicConfig(level = logging.DEBUG,
                        format = '%(asctime)s:%(levelname)s:%(message)s',
                        handlers = handlers)

    # you can now use the following logging value's: debug, info, warning, error, critical
    logging.debug('Starting main application')
    logging.info('Starting main application')
    logging.warning('Starting main application')
    logging.error('Starting main application')
    logging.critical('Starting main application')
    
    # Call the Main class
    main = Main()
    Gtk.main()
