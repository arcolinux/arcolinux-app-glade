#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import gi

gi.require_version('Gtk','3.0')
from gi.repository import Gtk, Gdk

class Main:
    def __init__(self):

        # Use Gtk builder to build the glade file
        gGui = "gGui.glade"
        self.builder = Gtk.Builder()
        self.builder.add_from_file(gGui)
        
        # Connect all the signals you have set in glade
        self.builder.connect_signals(self)
        
        # Assign the ID used in glade for the main window to hWindow
        hWindow = self.builder.get_object("hWindow")
        
        # Ensure delete event is assigned to quit
        hWindow.connect("delete-event", Gtk.main_quit)

        # Show the window
        hWindow.show()
        

        
    # When you click the Create Button
    def on_btnCreate_clicked(self, widget):
        print("Create Button has been clicked")

    # Checkbox ticked or not, e.g alacritty -hold ??
    def on_chkHold_toggled(self, widget):
        if widget.get_active():
            print("Checkbox toggled on: e.g alacritty -hold")
        else:
            print("checkbox toggle off: e.g alacritty -c")

    # When changing the drop down box 
    def on_cbIso_changed(self, widget):
        text = widget.get_active_text()
        if text is not None:
            print("Selected: %s" % text)
        


if __name__ == "__main__":
    main = Main()
    Gtk.main()
